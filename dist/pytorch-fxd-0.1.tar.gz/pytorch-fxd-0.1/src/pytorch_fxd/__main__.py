import pytorch_fxd.utils

pytorch_fxd.utils.main()
